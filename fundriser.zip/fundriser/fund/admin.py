from django.contrib import admin  
from .models import Funds  
   
   
admin.site.register(Funds) 