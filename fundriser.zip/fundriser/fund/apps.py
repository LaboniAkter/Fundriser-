from django.apps import AppConfig


class FundConfig(AppConfig):
    name = 'fund'
