from django.contrib import admin  
from .models import CRUD  
   
admin.site.register(CRUD) 
