from django.apps import AppConfig


class CrudFbvsConfig(AppConfig):
    name = 'CRUD_FBVs'
